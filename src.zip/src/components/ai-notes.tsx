"use client";

import { useEffect, useState } from "react";

import {
  BookOpen,
  CheckCircle2,
  FileText,
  Sparkles,
} from "lucide-react";

type AiNote = {
  id: number;
  userId: number;
  lessonId: number;
  content: string;
  createdAt: string;
  updatedAt: string;
};

type AiNotesProps = {
  lessonId: number;
};

/* =========================================================
   RENDER AI NOTES
========================================================= */

function renderNotes(text: string) {
  return text
    .split("\n")
    .map((line, index) => {
      const key = `${index}-${line}`;

      /* =====================================================
         H2
      ===================================================== */

      if (line.startsWith("## ")) {
        return (
          <div
            key={key}
            className="mt-8 first:mt-0"
          >
            <h3 className="text-base font-bold tracking-tight text-zinc-950 dark:text-white">
              {line.slice(3)}
            </h3>

            <div className="mt-2 h-px w-full bg-zinc-200 dark:bg-zinc-800" />
          </div>
        );
      }

      /* =====================================================
         H3
      ===================================================== */

      if (line.startsWith("### ")) {
        return (
          <h4
            key={key}
            className="mt-6 text-sm font-bold text-zinc-900 dark:text-white"
          >
            {line.slice(4)}
          </h4>
        );
      }

      /* =====================================================
         BULLET
      ===================================================== */

      if (/^[-*]\s+/.test(line)) {
        return (
          <div
            key={key}
            className="mt-2.5 flex gap-3 text-sm leading-7 text-zinc-600 dark:text-zinc-300"
          >
            <span className="mt-[11px] h-1.5 w-1.5 shrink-0 rounded-full bg-indigo-500" />

            <span>
              {line.replace(
                /^[-*]\s+/,
                ""
              )}
            </span>
          </div>
        );
      }

      /* =====================================================
         NUMBERED LIST
      ===================================================== */

      if (/^\d+\.\s+/.test(line)) {
        const match = line.match(
          /^(\d+)\.\s+(.*)$/
        );

        return (
          <div
            key={key}
            className="mt-2.5 flex gap-3 text-sm leading-7 text-zinc-600 dark:text-zinc-300"
          >
            <span className="flex h-6 min-w-6 shrink-0 items-center justify-center rounded-lg bg-indigo-50 text-[10px] font-bold text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
              {match?.[1]}
            </span>

            <span>
              {match?.[2]}
            </span>
          </div>
        );
      }

      /* =====================================================
         EMPTY LINE
      ===================================================== */

      if (!line.trim()) {
        return (
          <div
            key={key}
            className="h-2"
          />
        );
      }

      /* =====================================================
         NORMAL TEXT
      ===================================================== */

      return (
        <p
          key={key}
          className="mt-2.5 text-sm leading-7 text-zinc-600 dark:text-zinc-300"
        >
          {line}
        </p>
      );
    });
}

/* =========================================================
   AI NOTES COMPONENT
========================================================= */

export default function AiNotes({
  lessonId,
}: AiNotesProps) {
  const [note, setNote] =
    useState<AiNote | null>(null);

  const [loading, setLoading] =
    useState(true);

  const [generating, setGenerating] =
    useState(false);

  const [error, setError] =
    useState("");

  /* =======================================================
     LOAD SHARED NOTES
  ======================================================= */

  async function loadNote() {
    try {
      setLoading(true);
      setError("");

      const response =
        await fetch(
          `/api/ai-notes?lessonId=${lessonId}`,
          {
            cache: "no-store",
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ||
            "Failed to load AI notes"
        );
      }

      setNote(
        data.note ?? null
      );
    } catch (error) {
      console.error(
        "Load AI notes error:",
        error
      );

      setError(
        error instanceof Error
          ? error.message
          : "Failed to load AI notes"
      );
    } finally {
      setLoading(false);
    }
  }

  /* =======================================================
     GENERATE NOTES
  ======================================================= */

  async function generateNotes() {
    try {
      setGenerating(true);
      setError("");

      const response =
        await fetch(
          "/api/ai-notes",
          {
            method: "POST",

            headers: {
              "Content-Type":
                "application/json",
            },

            body: JSON.stringify({
              lessonId,
            }),
          }
        );

      const data =
        await response.json();

      if (!response.ok) {
        throw new Error(
          data?.error ||
            "Failed to generate notes"
        );
      }

      setNote(
        data.note ?? null
      );
    } catch (error) {
      console.error(
        "Generate AI notes error:",
        error
      );

      setError(
        error instanceof Error
          ? error.message
          : "Failed to generate notes"
      );
    } finally {
      setGenerating(false);
    }
  }

  /* =======================================================
     LOAD WHEN LESSON CHANGES
  ======================================================= */

  useEffect(() => {
    void loadNote();
  }, [lessonId]);

  /* =======================================================
     LOADING
  ======================================================= */

  if (loading) {
    return (
      <div className="rounded-2xl border border-zinc-200 bg-white p-6 shadow-sm dark:border-zinc-800 dark:bg-zinc-900">

        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-indigo-50 dark:bg-indigo-950/40">

            <FileText
              size={18}
              className="text-indigo-400"
            />

          </div>

          <div className="space-y-2">

            <div className="h-3 w-28 animate-pulse rounded bg-zinc-200 dark:bg-zinc-800" />

            <div className="h-2.5 w-56 animate-pulse rounded bg-zinc-100 dark:bg-zinc-800" />

          </div>

        </div>

      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-2xl border border-zinc-200 bg-white shadow-sm dark:border-zinc-800 dark:bg-zinc-900">

      {/* =====================================================
          HEADER
      ===================================================== */}

      <div className="border-b border-zinc-100 px-6 py-5 dark:border-zinc-800 sm:px-7">

        <div className="flex items-center gap-3">

          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400">
            <Sparkles size={19} />
          </div>

          <div className="min-w-0">

            <div className="flex flex-wrap items-center gap-2">

              <h2 className="text-base font-bold text-zinc-950 dark:text-white">
                AI Notes
              </h2>

              {note && (
                <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-1 text-[10px] font-semibold text-emerald-600 dark:bg-emerald-950/30 dark:text-emerald-400">

                  <CheckCircle2 size={11} />

                  Available for everyone

                </span>
              )}

            </div>

            <p className="mt-1 text-xs text-zinc-500 dark:text-zinc-400">
              AI-generated study notes for this lesson
              <span className="mx-1.5">•</span>
              Read-only
            </p>

          </div>

        </div>

      </div>

      {/* =====================================================
          ERROR
      ===================================================== */}

      {error && (
        <div className="mx-6 mt-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-xs leading-5 text-red-600 dark:border-red-900/40 dark:bg-red-950/20 dark:text-red-400 sm:mx-7">
          {error}
        </div>
      )}

      {/* =====================================================
          NO NOTES
      ===================================================== */}

      {!note && !error && (
        <div className="p-6 sm:p-7">

          <div className="rounded-xl border border-dashed border-zinc-200 bg-zinc-50 px-5 py-10 text-center dark:border-zinc-800 dark:bg-zinc-950/50">

            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-white text-indigo-500 shadow-sm dark:bg-zinc-900">

              <BookOpen size={20} />

            </div>

            <h3 className="mt-4 text-sm font-semibold text-zinc-900 dark:text-white">
              AI notes are not available yet
            </h3>

            <p className="mx-auto mt-2 max-w-md text-xs leading-5 text-zinc-500 dark:text-zinc-400">
              Generate the official study notes
              for this lesson. Once generated,
              the same notes will be available
              to every learner.
            </p>

            <button
              type="button"
              onClick={
                generateNotes
              }
              disabled={
                generating
              }
              className="mt-5 inline-flex h-10 items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 text-xs font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
            >

              {generating ? (
                <>
                  <span className="h-3.5 w-3.5 animate-spin rounded-full border-2 border-white/30 border-t-white" />

                  Generating notes...

                </>
              ) : (
                <>
                  <Sparkles size={14} />

                  Generate notes

                </>
              )}

            </button>

          </div>

        </div>
      )}

      {/* =====================================================
          GENERATED NOTES
      ===================================================== */}

      {note && (
        <div className="p-6 sm:p-7">

          <div className="rounded-xl bg-zinc-50 px-5 py-6 dark:bg-zinc-950/50 sm:px-7 sm:py-7">

            <div className="max-w-4xl">

              {renderNotes(
                note.content
              )}

            </div>

          </div>

          {/* =================================================
              READ ONLY
          ================================================= */}

          <div className="mt-4 flex items-start gap-2 rounded-xl bg-zinc-50 px-4 py-3 dark:bg-zinc-950/40">

            <CheckCircle2
              size={13}
              className="mt-0.5 shrink-0 text-emerald-500"
            />

            <p className="text-[11px] leading-5 text-zinc-400">
              These notes are generated once
              for this lesson and shared with
              all learners. They are read-only
              and cannot be edited.
            </p>

          </div>

        </div>
      )}

    </div>
  );
}