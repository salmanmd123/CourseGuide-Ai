import { NextResponse } from "next/server";

import {
    ilike,
    inArray,
    or,
} from "drizzle-orm";

import { db } from "@/db";

import {
    courses,
    lessons,
} from "@/db/schema";

import {
    searchYouTubeCourses,
    formatYouTubeDuration,
    normalizeLanguage as normalizeYouTubeLanguage,
} from "@/lib/youtube";


/* =========================================================
   CREATE SLUG
========================================================= */

function createSlug(
    title: string,
    id: string
): string {

    const slug =
        title
            .toLowerCase()
            .replace(
                /[^a-z0-9]+/g,
                "-"
            )
            .replace(
                /^-|-$/g,
                ""
            )
            .slice(
                0,
                150
            );

    return `${slug}-${id}`;
}


/* =========================================================
   NORMALIZE TEXT
========================================================= */

function normalizeText(
    text: string
): string {
    return text
        .toLowerCase()
        .replace(
            /\s+/g,
            " "
        )
        .trim();
}


/* =========================================================
   NORMALIZE QUERY
========================================================= */

function normalizeCourseQuery(
    query: string
): string {

    const normalized =
        normalizeText(query);

    if (
        normalized === "cpp" ||
        normalized === "c ++" ||
        normalized === "c plus plus"
    ) {
        return "c++";
    }

    if (
        normalized ===
            "java script" ||
        normalized === "js"
    ) {
        return "javascript";
    }

    if (
        normalized ===
            "type script" ||
        normalized === "ts"
    ) {
        return "typescript";
    }

    if (
        normalized ===
            "reactjs"
    ) {
        return "react";
    }

    if (
        normalized ===
            "nodejs" ||
        normalized ===
            "node.js"
    ) {
        return "node";
    }

    if (
        normalized ===
            "mongo db"
    ) {
        return "mongodb";
    }

    return normalized;
}


/* =========================================================
   GET CANONICAL COURSE CATEGORY
========================================================= */

function getCourseCategory(
    query: string
): string {

    const normalized =
        normalizeCourseQuery(query);

    /* =========================
       PROGRAMMING
    ========================= */

    if (
        normalized === "python" ||
        normalized === "java" ||
        normalized === "c" ||
        normalized === "c++" ||
        normalized === "javascript" ||
        normalized === "typescript" ||
        normalized === "go" ||
        normalized === "golang" ||
        normalized === "rust" ||
        normalized === "kotlin" ||
        normalized === "swift" ||
        normalized === "ruby" ||
        normalized === "programming" ||
        normalized === "coding"
    ) {
        return "Programming";
    }

    /* =========================
       WEB DEVELOPMENT
    ========================= */

    if (
        normalized === "react" ||
        normalized === "php" ||
        normalized === "html" ||
        normalized === "css" ||
        normalized === "mern" ||
        normalized === "mean" ||
        normalized === "node" ||
        normalized === "express" ||
        normalized === "nextjs" ||
        normalized === "next.js" ||
        normalized === "frontend" ||
        normalized === "backend" ||
        normalized === "full stack" ||
        normalized === "fullstack" ||
        normalized === "web development"
    ) {
        return "Web Development";
    }

    /* =========================
       DATABASES
    ========================= */

    if (
        normalized === "sql" ||
        normalized === "mysql" ||
        normalized === "postgresql" ||
        normalized === "postgres" ||
        normalized === "mongodb" ||
        normalized === "mongo" ||
        normalized === "dbms" ||
        normalized === "database" ||
        normalized === "databases" ||
        normalized === "redis" ||
        normalized === "sqlite" ||
        normalized === "firebase"
    ) {
        return "Databases";
    }

    /* =========================
       AI & ML
    ========================= */

    if (
        normalized === "ai" ||
        normalized === "artificial intelligence" ||
        normalized === "ml" ||
        normalized === "machine learning" ||
        normalized === "deep learning" ||
        normalized === "nlp" ||
        normalized === "natural language processing" ||
        normalized === "computer vision" ||
        normalized === "cv" ||
        normalized === "generative ai" ||
        normalized === "genai" ||
        normalized === "tensorflow" ||
        normalized === "pytorch" ||
        normalized === "neural networks"
    ) {
        return "AI & ML";
    }

    /* =========================
       COMPUTER SCIENCE
    ========================= */

    if (
        normalized === "dsa" ||
        normalized === "data structures" ||
        normalized === "data structures and algorithms" ||
        normalized === "algorithms" ||
        normalized === "operating systems" ||
        normalized === "os" ||
        normalized === "computer networks" ||
        normalized === "networks" ||
        normalized === "computer science" ||
        normalized === "software engineering" ||
        normalized === "discrete mathematics" ||
        normalized === "discrete math" ||
        normalized === "theory of computation" ||
        normalized === "compiler design" ||
        normalized === "computer architecture"
    ) {
        return "Computer Science";
    }

    /*
     * Safe fallback: preserve the search query when it is not one
     * of the supported canonical categories. This avoids silently
     * assigning an unrelated category to a newly discovered course.
     */
    return query.trim();
}


/* =========================================================
   DATABASE COURSE RELEVANCE
========================================================= */

function isRelevantDatabaseCourse(
    title: string,
    description: string,
    category: string,
    channelName: string | null,
    query: string
): boolean {

    /*
     * Keep the same intentional behavior:
     *
     * Subject relevance is based mainly on
     * title/category rather than arbitrary
     * description mentions.
     */

    void description;

    void channelName;

    const normalizedQuery =
        normalizeCourseQuery(
            query
        );

    const normalizedTitle =
        normalizeText(
            title
        );

    const normalizedCategory =
        normalizeText(
            category
        );


    /* C++ */

    if (
        normalizedQuery ===
        "c++"
    ) {
        return (
            normalizedTitle.includes(
                "c++"
            ) ||
            normalizedTitle.includes(
                "cpp"
            ) ||
            normalizedCategory.includes(
                "c++"
            ) ||
            normalizedCategory.includes(
                "cpp"
            )
        );
    }


    /* C */

    if (
        normalizedQuery ===
        "c"
    ) {
        const titleIsC =
            /\bc\b/i.test(
                normalizedTitle
            );

        const categoryIsC =
            /\bc\b/i.test(
                normalizedCategory
            );

        const isCpp =
            /\bc\s*\+\+/i.test(
                normalizedTitle
            ) ||
            /\bc\s*\+\+/i.test(
                normalizedCategory
            );

        const isCSharp =
            /\bc\s*#/i.test(
                normalizedTitle
            ) ||
            /\bc\s*#/i.test(
                normalizedCategory
            );

        return (
            (titleIsC || categoryIsC) &&
            !isCpp &&
            !isCSharp
        );
    }


    /* JAVASCRIPT */

    if (
        normalizedQuery ===
        "javascript"
    ) {
        return (
            /\bjavascript\b/i.test(
                normalizedTitle
            ) ||
            /\bjava script\b/i.test(
                normalizedTitle
            ) ||
            /\becmascript\b/i.test(
                normalizedTitle
            ) ||
            /\bjs\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "javascript"
            )
        );
    }


    /* TYPESCRIPT */

    if (
        normalizedQuery ===
        "typescript"
    ) {
        return (
            /\btypescript\b/i.test(
                normalizedTitle
            ) ||
            /\btype script\b/i.test(
                normalizedTitle
            ) ||
            /\bts\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "typescript"
            )
        );
    }


    /* JAVA */

    if (
        normalizedQuery ===
        "java"
    ) {
        return (
            /\bjava\b/i.test(
                normalizedTitle
            ) &&
            !/\bjavascript\b/i.test(
                normalizedTitle
            )
        );
    }


    /* PYTHON */

    if (
        normalizedQuery ===
        "python"
    ) {
        return (
            /\bpython\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "python"
            )
        );
    }


    /* REACT */

    if (
        normalizedQuery ===
        "react"
    ) {
        return (
            /\breact\b/i.test(
                normalizedTitle
            ) ||
            /\breactjs\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "react"
            )
        );
    }


    /* SQL */

    if (
        normalizedQuery ===
        "sql"
    ) {
        return (
            /\bsql\b/i.test(
                normalizedTitle
            ) ||
            /\bsql\b/i.test(
                normalizedCategory
            )
        );
    }


    /* HTML */

    if (
        normalizedQuery ===
        "html"
    ) {
        return (
            /\bhtml\b/i.test(
                normalizedTitle
            ) ||
            /\bhtml5\b/i.test(
                normalizedTitle
            ) ||
            /\bhtml\b/i.test(
                normalizedCategory
            )
        );
    }


    /* CSS */

    if (
        normalizedQuery ===
        "css"
    ) {
        return (
            /\bcss\b/i.test(
                normalizedTitle
            ) ||
            /\bcss3\b/i.test(
                normalizedTitle
            ) ||
            /\bcss\b/i.test(
                normalizedCategory
            )
        );
    }


    /* NODE */

    if (
        normalizedQuery ===
        "node"
    ) {
        return (
            /\bnode\.?js\b/i.test(
                normalizedTitle
            ) ||
            /\bnode js\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "node"
            )
        );
    }


    /* MONGODB */

    if (
        normalizedQuery ===
        "mongodb"
    ) {
        return (
            /\bmongodb\b/i.test(
                normalizedTitle
            ) ||
            /\bmongo db\b/i.test(
                normalizedTitle
            ) ||
            normalizedCategory.includes(
                "mongodb"
            ) ||
            normalizedCategory.includes(
                "mongo"
            )
        );
    }


    /* NORMAL */

    const queryWords =
        normalizedQuery
            .split(
                /\s+/
            )
            .filter(Boolean);

    if (
        queryWords.length === 0
    ) {
        return false;
    }

    return queryWords.every(
        (word) =>
            normalizedTitle.includes(
                word
            ) ||
            normalizedCategory.includes(
                word
            )
    );
}


/* =========================================================
   RECOMMENDATION SCORE
========================================================= */

function calculateRecommendationScore({
    title,
    description,
    views,
    likes,
    durationSeconds,
    query,
    lessonCount,
    courseType,
}: {
    title: string;
    description: string;
    views: number;
    likes: number;
    durationSeconds: number;
    query: string;
    lessonCount: number;
    courseType:
        | "VIDEO"
        | "PLAYLIST";
}): number {

    const text =
        normalizeText(
            `${title} ${description}`
        );

    const searchQuery =
        normalizeCourseQuery(
            query
        );

    let score = 0;


    /* =====================================================
       SEARCH RELEVANCE
       MAX 30
    ===================================================== */

    if (
        searchQuery === "c++"
    ) {

        if (
            text.includes("c++") ||
            text.includes("cpp") ||
            text.includes(
                "c plus plus"
            )
        ) {
            score += 30;
        }

    } else {

        const queryWords =
            searchQuery
                .split(/\s+/)
                .filter(Boolean);

        let matchedWords = 0;

        for (
            const word of
            queryWords
        ) {
            if (
                text.includes(
                    word
                )
            ) {
                matchedWords++;
            }
        }

        if (
            queryWords.length >
            0
        ) {
            score +=
                (
                    matchedWords /
                    queryWords.length
                ) *
                30;
        }
    }


    /* =====================================================
       VIEWS
       MAX 20
    ===================================================== */

    if (
        views >=
        10_000_000
    ) {
        score += 20;

    } else if (
        views >=
        5_000_000
    ) {
        score += 18;

    } else if (
        views >=
        1_000_000
    ) {
        score += 16;

    } else if (
        views >=
        500_000
    ) {
        score += 13;

    } else if (
        views >=
        100_000
    ) {
        score += 10;

    } else if (
        views >=
        10_000
    ) {
        score += 6;

    } else {
        score += 2;
    }


    /* =====================================================
       LIKE ENGAGEMENT
       MAX 15
    ===================================================== */

    const likeRatio =
        views > 0
            ? likes / views
            : 0;

    if (
        likeRatio >= 0.08
    ) {
        score += 15;

    } else if (
        likeRatio >= 0.05
    ) {
        score += 13;

    } else if (
        likeRatio >= 0.03
    ) {
        score += 10;

    } else if (
        likeRatio >= 0.01
    ) {
        score += 7;

    } else {
        score += 3;
    }


    /* =====================================================
       COURSE SIGNAL
       MAX 25
    ===================================================== */

    const courseKeywords = [
        "full course",
        "complete course",
        "full tutorial",
        "complete tutorial",
        "course for beginners",
        "beginner course",
        "from basics",
        "from scratch",
        "zero to hero",
        "tutorial",
        "masterclass",
        "bootcamp",
    ];

    if (
        courseKeywords.some(
            (keyword) =>
                text.includes(
                    keyword
                )
        )
    ) {
        score += 25;

    } else {
        score += 5;
    }


    /* =====================================================
       DURATION
       MAX 10
    ===================================================== */

    if (
        durationSeconds >=
        8 * 60 * 60
    ) {
        score += 10;

    } else if (
        durationSeconds >=
        4 * 60 * 60
    ) {
        score += 9;

    } else if (
        durationSeconds >=
        2 * 60 * 60
    ) {
        score += 8;

    } else if (
        durationSeconds >=
        60 * 60
    ) {
        score += 6;

    } else if (
        durationSeconds >=
        30 * 60
    ) {
        score += 4;

    } else {
        score += 1;
    }


    /* =====================================================
       PLAYLIST BONUS
    ===================================================== */

    if (
        courseType ===
        "PLAYLIST"
    ) {

        if (
            lessonCount >=
            30
        ) {
            score += 10;

        } else if (
            lessonCount >=
            15
        ) {
            score += 8;

        } else if (
            lessonCount >=
            8
        ) {
            score += 6;

        } else if (
            lessonCount >=
            4
        ) {
            score += 3;
        }
    }


    return Math.round(
        Math.min(
            100,
            score
        )
    );
}


/* =========================================================
   GET SEARCH QUERY
========================================================= */

function getSearchQuery(
    request: Request
): string {

    const url =
        new URL(
            request.url
        );

    const rawQuery =
        url.searchParams.get(
            "q"
        );

    if (
        !rawQuery
    ) {
        return "";
    }

    return rawQuery.trim();
}


/* =========================================================
   NORMALIZE LANGUAGE
========================================================= */

function normalizeLanguage(
    language:
        | string
        | null
): string {

    const normalized =
        normalizeYouTubeLanguage(
            language ||
                ""
        );

    if (
        normalized ===
        "hindi"
    ) {
        return "Hindi";
    }

    if (
        normalized ===
        "english"
    ) {
        return "English";
    }

    if (
        normalized ===
        "hinglish"
    ) {
        return "Hinglish";
    }

    return normalized || "Unknown";
}


/* =========================================================
   EXPLICIT LANGUAGE DETECTION FOR DATABASE COURSES
========================================================= */

const DATABASE_LANGUAGE_PATTERNS: Array<{
    language: string;
    patterns: RegExp[];
}> = [
    { language: "hindi", patterns: [/\bhindi\b/i, /\bin\s+hindi\b/i, /\bhindi\s+(?:mein|me)\b/i, /हिंदी/, /हिन्दी/, /हिंदी\s*में/, /हिन्दी\s*में/] },
    { language: "telugu", patterns: [/\btelugu\b/i, /\bin\s+telugu\b/i, /తెలుగు/, /తెలుగులో/] },
    { language: "tamil", patterns: [/\btamil\b/i, /\bin\s+tamil\b/i, /தமிழ்/, /தமிழில்/] },
    { language: "kannada", patterns: [/\bkannada\b/i, /\bin\s+kannada\b/i, /ಕನ್ನಡ/, /ಕನ್ನಡದಲ್ಲಿ/] },
    { language: "malayalam", patterns: [/\bmalayalam\b/i, /\bin\s+malayalam\b/i, /മലയാളം/, /മലയാളത്തിൽ/] },
    { language: "bengali", patterns: [/\bbengali\b/i, /\bin\s+bengali\b/i, /বাংলা/, /বাংলায়/] },
    { language: "marathi", patterns: [/\bmarathi\b/i, /\bin\s+marathi\b/i, /मराठी/, /मराठीत/] },
    { language: "gujarati", patterns: [/\bgujarati\b/i, /\bin\s+gujarati\b/i, /ગુજરાતી/, /ગુજરાતીમાં/] },
    { language: "punjabi", patterns: [/\bpunjabi\b/i, /\bin\s+punjabi\b/i, /ਪੰਜਾਬੀ/, /ਪੰਜਾਬੀ ਵਿੱਚ/] },
    { language: "urdu", patterns: [/\burdu\b/i, /\bin\s+urdu\b/i, /اردو/, /اردو میں/] },
    { language: "odia", patterns: [/\b(?:odia|oriya)\b/i, /\bin\s+(?:odia|oriya)\b/i, /ଓଡ଼ିଆ/, /ଓଡ଼ିଆରେ/] },
    { language: "assamese", patterns: [/\bassamese\b/i, /\bin\s+assamese\b/i, /অসমীয়া/, /অসমীয়াত/] },
    { language: "nepali", patterns: [/\bnepali\b/i, /\bin\s+nepali\b/i, /नेपाली/, /नेपालीमा/] },
    { language: "french", patterns: [/\bfrench\b/i, /\bin\s+french\b/i, /\bfrench\s+language\b/i] },
    { language: "spanish", patterns: [/\bspanish\b/i, /\bin\s+spanish\b/i, /\bspanish\s+language\b/i] },
    { language: "german", patterns: [/\bgerman\b/i, /\bin\s+german\b/i, /\bgerman\s+language\b/i] },
    { language: "portuguese", patterns: [/\bportuguese\b/i, /\bin\s+portuguese\b/i, /\bportuguese\s+language\b/i] },
    { language: "english", patterns: [/\benglish\b/i, /\bin\s+english\b/i, /\benglish\s+language\b/i] },
];

function detectExplicitLanguageFromCourseText(
    title: string | null | undefined,
    description: string | null | undefined
): string | null {
    const titleText = (title || "").trim();
    const descriptionText = (description || "").trim();

    const detect = (text: string): string[] =>
        DATABASE_LANGUAGE_PATTERNS
            .filter(({ patterns }) =>
                patterns.some((pattern) => pattern.test(text))
            )
            .map(({ language }) => language);

    const titleMatches = Array.from(new Set(detect(titleText)));
    if (titleMatches.length === 1) return titleMatches[0];

    const descriptionMatches = Array.from(new Set(detect(descriptionText)));
    if (descriptionMatches.length === 1) return descriptionMatches[0];

    const combined = `${titleText} ${descriptionText}`;

    if (/[\u0C00-\u0C7F]/.test(combined)) return "telugu";
    if (/[\u0B80-\u0BFF]/.test(combined)) return "tamil";
    if (/[\u0C80-\u0CFF]/.test(combined)) return "kannada";
    if (/[\u0D00-\u0D7F]/.test(combined)) return "malayalam";
    if (/[\u0980-\u09FF]/.test(combined)) return "bengali";
    if (/[\u0A80-\u0AFF]/.test(combined)) return "gujarati";
    if (/[\u0A00-\u0A7F]/.test(combined)) return "punjabi";
    if (/[\u0B00-\u0B7F]/.test(combined)) return "odia";
    if (/[\u0600-\u06FF]/.test(combined)) return "urdu";
    if (/[\u0900-\u097F]/.test(combined)) return "hindi";

    return null;
}

function matchesPreferredDatabaseLanguage(
    courseLanguage: string | null | undefined,
    title: string | null | undefined,
    description: string | null | undefined,
    preferredLanguage: string
): boolean {
    const storedLanguage = normalizeText(courseLanguage || "");
    const explicitLanguage = detectExplicitLanguageFromCourseText(title, description);

    if (explicitLanguage) return explicitLanguage === preferredLanguage;
    if (!storedLanguage || storedLanguage === "unknown") return false;

    return storedLanguage === preferredLanguage;
}


/* =========================================================
   GET SEARCH API
========================================================= */

export async function GET(
    request: Request
) {

    try {

        const query =
            getSearchQuery(
                request
            );

        const url =
            new URL(
                request.url
            );

        const preferredLanguage =
            normalizeLanguage(
                url.searchParams.get(
                    "language"
                )
            );

        const normalizedPreferredLanguage =
            normalizeText(
                preferredLanguage
            );


        console.log(
            "================================"
        );

        console.log(
            "Searching courses for:",
            query
        );

        console.log(
            "Preferred language:",
            preferredLanguage
        );

        console.log(
            "================================"
        );


        if (
            !query
        ) {

            return NextResponse.json(
                {
                    error:
                        "Search query is required",
                },
                {
                    status: 400,
                }
            );
        }


        /* =================================================
           1. DATABASE FIRST
        ================================================= */

        const existingCourses =
            await db
                .select()
                .from(courses)
                .where(
                    or(
                        ilike(
                            courses.title,
                            `%${query}%`
                        ),

                        ilike(
                            courses.category,
                            `%${query}%`
                        )
                    )
                );


        console.log(
            "Database courses found:",
            existingCourses.length
        );


        /* =================================================
           2. STRICT SUBJECT FILTER
        ================================================= */

        const relevantDatabaseCourses =
            existingCourses.filter(
                (course) =>
                    isRelevantDatabaseCourse(
                        course.title,
                        course.description,
                        course.category,
                        course.channelName,
                        query
                    )
            );


        /* =================================================
           3. LANGUAGE HARD FILTER
        ================================================= */

        const languageFilteredCourses =
            relevantDatabaseCourses.filter(
                (course) => {

                    return matchesPreferredDatabaseLanguage(
                        course.language,
                        course.title,
                        course.description,
                        normalizedPreferredLanguage
                    );
                }
            );


        console.log(
            "Database courses after language filter:",
            languageFilteredCourses.length
        );


        /* =================================================
           RETURN DATABASE COURSES
        ================================================= */

        if (
            languageFilteredCourses.length >
            0
        ) {

            languageFilteredCourses.sort(
                (a, b) =>
                    (
                        b.recommendationScore ??
                        0
                    ) -
                    (
                        a.recommendationScore ??
                        0
                    )
            );


            return NextResponse.json({
                source:
                    "database",

                courses:
                    languageFilteredCourses,
            });
        }


        console.log(
            "No matching database courses in preferred language."
        );

        console.log(
            "Searching YouTube..."
        );


        /* =================================================
           4. YOUTUBE SEARCH
        ================================================= */

        const youtubeResults =
            await searchYouTubeCourses(
                query,
                preferredLanguage
            );


        console.log(
            "YouTube results:",
            youtubeResults.length
        );


        if (
            youtubeResults.length ===
            0
        ) {

            return NextResponse.json({
                source:
                    "youtube",

                courses: [],
            });
        }


        /* =================================================
           5. STRICT SUBJECT FILTER FOR YOUTUBE
        ================================================= */

        const subjectMatchedResults =
            youtubeResults.filter(
                (video) => {
                    const normalizedVideoQuery =
                        normalizeCourseQuery(
                            query
                        );

                    const title =
                        normalizeText(
                            video.title
                        );

                    if (
                        normalizedVideoQuery ===
                        "c"
                    ) {
                        const isC =
                            /\bc\b/i.test(
                                title
                            );

                        const isCpp =
                            /\bc\s*\+\+/i.test(
                                title
                            ) ||
                            /\bcpp\b/i.test(
                                title
                            ) ||
                            /\bc\s+plus\s+plus\b/i.test(
                                title
                            );

                        const isCSharp =
                            /\bc\s*#/i.test(
                                title
                            );

                        if (
                            !isC ||
                            isCpp ||
                            isCSharp
                        ) {
                            console.log(
                                "[REMOVE - SUBJECT]",
                                video.title,
                                "-> C search"
                            );
                            return false;
                        }
                    }

                    if (
                        normalizedVideoQuery ===
                        "c++"
                    ) {
                        const isCpp =
                            /\bc\s*\+\+/i.test(
                                title
                            ) ||
                            /\bcpp\b/i.test(
                                title
                            ) ||
                            /\bc\s+plus\s+plus\b/i.test(
                                title
                            );

                        if (!isCpp) {
                            console.log(
                                "[REMOVE - SUBJECT]",
                                video.title,
                                "-> C++ search"
                            );
                            return false;
                        }
                    }

                    return true;
                }
            );


        /* =================================================
           6. LANGUAGE HARD FILTER
        ================================================= */

        const languageMatchedResults =
            subjectMatchedResults.filter(
                (video) => {

                    const videoLanguage =
                        normalizeYouTubeLanguage(
                            video.language
                        );

                    const matches =
                        videoLanguage ===
                        normalizedPreferredLanguage;


                    if (
                        !matches
                    ) {
                        console.log(
                            "[REMOVE - LANGUAGE]",
                            video.title,
                            "->",
                            video.language
                        );
                    }


                    return matches;
                }
            );


        if (
            languageMatchedResults.length ===
            0
        ) {

            return NextResponse.json({
                source:
                    "youtube",

                courses: [],
            });
        }


        /* =================================================
           7. SCORE VIDEO + PLAYLIST RESULTS
        ================================================= */

        const scoredCourses =
            languageMatchedResults.map(
                (video) => {

                    const views =
                        video.views ||
                        0;

                    const likes =
                        video.likes ||
                        0;

                    const durationSeconds =
                        video.durationSeconds ||
                        0;

                    const lessonCount =
                        video.courseType ===
                        "PLAYLIST"
                            ? (
                                video.lessons
                                    ?.length ||
                                0
                            )
                            : 1;


                    let recommendationScore =
                        calculateRecommendationScore(
                            {
                                title:
                                    video.title,

                                description:
                                    video.description,

                                views,

                                likes,

                                durationSeconds,

                                query,

                                lessonCount,

                                courseType:
                                    video.courseType,
                            }
                        );


                    /*
                     * Every result already passed
                     * the language hard filter.
                     */

                    recommendationScore +=
                        15;

                    recommendationScore =
                        Math.min(
                            100,
                            recommendationScore
                        );


                    return {
                        video,

                        recommendationScore,
                    };
                }
            );


        /* =================================================
           8. SORT
        ================================================= */

        scoredCourses.sort(
            (a, b) =>
                b.recommendationScore -
                a.recommendationScore
        );


        /* =================================================
           9. TOP 10
        ================================================= */

        const topCourses =
            scoredCourses.slice(
                0,
                10
            );


        /* =================================================
           10. EXISTING VIDEO COURSES
        ================================================= */

        const videoIds =
            topCourses
                .filter(
                    (item) =>
                        item.video
                            .courseType ===
                        "VIDEO"
                )
                .map(
                    (item) =>
                        item.video
                            .videoId
                )
                .filter(Boolean);


        /* =================================================
           11. EXISTING PLAYLIST COURSES
        ================================================= */

        const playlistIds =
            topCourses
                .filter(
                    (item) =>
                        item.video
                            .courseType ===
                        "PLAYLIST"
                )
                .map(
                    (item) =>
                        item.video
                            .playlistId
                )
                .filter(
                    (
                        id
                    ): id is string =>
                        Boolean(id)
                );


        const existingVideoCourses =
            videoIds.length > 0
                ? await db
                    .select()
                    .from(courses)
                    .where(
                        inArray(
                            courses.youtubeId,
                            videoIds
                        )
                    )
                : [];


        const existingPlaylistCourses =
            playlistIds.length > 0
                ? await db
                    .select()
                    .from(courses)
                    .where(
                        inArray(
                            courses.youtubePlaylistId,
                            playlistIds
                        )
                    )
                : [];


        const existingVideoIds =
            new Set(
                existingVideoCourses
                    .map(
                        (course) =>
                            course.youtubeId
                    )
                    .filter(
                        (
                            id
                        ): id is string =>
                            Boolean(id)
                    )
            );


        const existingPlaylistIds =
            new Set(
                existingPlaylistCourses
                    .map(
                        (course) =>
                            course.youtubePlaylistId
                    )
                    .filter(
                        (
                            id
                        ): id is string =>
                            Boolean(id)
                    )
            );


        /* =================================================
           12. INSERT NEW COURSES
        ================================================= */

        for (
            const item of
            topCourses
        ) {

            const video =
                item.video;


            /* =================================================
               PLAYLIST
            ================================================= */

            if (
                video.courseType ===
                "PLAYLIST"
            ) {

                const playlistId =
                    video.playlistId;


                if (
                    !playlistId ||
                    !video.lessons ||
                    video.lessons.length ===
                        0
                ) {
                    continue;
                }


                if (
                    existingPlaylistIds.has(
                        playlistId
                    )
                ) {
                    continue;
                }


                try {

                    const totalDurationSeconds =
                        video.lessons.reduce(
                            (
                                total,
                                lesson
                            ) =>
                                total +
                                lesson.durationSeconds,
                            0
                        );


                    const totalDurationISO =
                        `PT${Math.floor(
                            totalDurationSeconds /
                                3600
                        )}H${Math.floor(
                            (
                                totalDurationSeconds %
                                3600
                            ) /
                                60
                        )}M${totalDurationSeconds % 60
                        }S`;


                    const duration =
                        video.duration ||
                        formatYouTubeDuration(
                            totalDurationISO
                        );


                    const [insertedCourse] =
                        await db
                            .insert(
                                courses
                            )
                            .values({

                                title:
                                    video.title,

                                slug:
                                    createSlug(
                                        video.title,
                                        playlistId
                                    ),

                                description:
                                    video.description ||
                                    "YouTube course playlist",

                                category:
                                    getCourseCategory(
                                        query
                                    ),

                                level:
                                    "Beginner",

                                courseType:
                                    "PLAYLIST",

                                language:
                                    video.language,

                                youtubeUrl:
                                    `https://www.youtube.com/playlist?list=${playlistId}`,

                                youtubeId:
                                    null,

                                youtubePlaylistId:
                                    playlistId,

                                channelName:
                                    video.channelName,

                                thumbnailUrl:
                                    video.thumbnail,

                                views:
                                    video.views ||
                                    0,

                                likes:
                                    video.likes ||
                                    0,

                                duration,

                                lessonsCount:
                                    video.lessons
                                        .length,

                                rating:
                                    "0",

                                students:
                                    "0",

                                source:
                                    "YouTube",

                                recommendationScore:
                                    item.recommendationScore,

                                adminRecommended:
                                    false,

                                featured:
                                    false,
                            })
                            .onConflictDoNothing(
                                {
                                    target:
                                        courses.youtubePlaylistId,
                                }
                            )
                            .returning();


                    if (
                        insertedCourse
                    ) {

                        for (
                            let index = 0;
                            index <
                            video.lessons.length;
                            index++
                        ) {

                            const lesson =
                                video.lessons[
                                    index
                                ];


                            await db
                                .insert(
                                    lessons
                                )
                                .values({

                                    courseId:
                                        insertedCourse.id,

                                    title:
                                        lesson.title,

                                    description:
                                        lesson.description,

                                    videoUrl:
                                        lesson.videoId,

                                    duration:
                                        lesson.duration,

                                    order:
                                        index + 1,
                                });
                        }


                        console.log(
                            `[PLAYLIST CREATED] ${insertedCourse.title} -> ${video.lessons.length} lessons`
                        );
                    }

                } catch (
                    error
                ) {

                    console.error(
                        `[PLAYLIST INSERT ERROR] ${video.title}`,
                        error
                    );
                }


                continue;
            }


            /* =================================================
               NORMAL VIDEO
            ================================================= */

            if (
                existingVideoIds.has(
                    video.videoId
                )
            ) {
                continue;
            }


            try {

                const [insertedCourse] =
                    await db
                        .insert(
                            courses
                        )
                        .values({

                            title:
                                video.title,

                            slug:
                                createSlug(
                                    video.title,
                                    video.videoId
                                ),

                            description:
                                video.description ||
                                "YouTube course",

                            category:
                                getCourseCategory(
                                    query
                                ),

                            level:
                                "Beginner",

                            courseType:
                                "VIDEO",

                            language:
                                video.language,

                            youtubeUrl:
                                `https://www.youtube.com/watch?v=${video.videoId}`,

                            youtubeId:
                                video.videoId,

                            youtubePlaylistId:
                                null,

                            channelName:
                                video.channelName,

                            thumbnailUrl:
                                video.thumbnail,

                            views:
                                video.views ||
                                0,

                            likes:
                                video.likes ||
                                0,

                            duration:
                                video.duration ||
                                "Unknown",

                            lessonsCount:
                                1,

                            rating:
                                "0",

                            students:
                                "0",

                            source:
                                "YouTube",

                            recommendationScore:
                                item.recommendationScore,

                            adminRecommended:
                                false,

                            featured:
                                false,
                        })
                        .onConflictDoNothing(
                            {
                                target:
                                    courses.youtubeId,
                            }
                        )
                        .returning();


                if (
                    insertedCourse
                ) {

                    await db
                        .insert(
                            lessons
                        )
                        .values({

                            courseId:
                                insertedCourse.id,

                            title:
                                insertedCourse.title,

                            description:
                                insertedCourse.description,

                            videoUrl:
                                insertedCourse.youtubeId!,

                            duration:
                                insertedCourse.duration,

                            order:
                                1,
                        });


                    console.log(
                        `[LESSON CREATED] ${insertedCourse.title}`
                    );
                }

            } catch (
                error
            ) {

                console.error(
                    `[COURSE INSERT ERROR] ${video.title}`,
                    error
                );
            }
        }


        /* =================================================
           13. FINAL FETCH
        ================================================= */

        const finalVideoCourses =
            videoIds.length > 0
                ? await db
                    .select()
                    .from(courses)
                    .where(
                        inArray(
                            courses.youtubeId,
                            videoIds
                        )
                    )
                : [];


        const finalPlaylistCourses =
            playlistIds.length > 0
                ? await db
                    .select()
                    .from(courses)
                    .where(
                        inArray(
                            courses.youtubePlaylistId,
                            playlistIds
                        )
                    )
                : [];


        const finalCourses =
            [
                ...finalVideoCourses,
                ...finalPlaylistCourses,
            ];


        /* =================================================
           14. FINAL SUBJECT + LANGUAGE FILTER
        ================================================= */

        const finalRelevantCourses =
            finalCourses.filter(
                (course) => {

                    const languageMatch =
                        matchesPreferredDatabaseLanguage(
                            course.language,
                            course.title,
                            course.description,
                            normalizedPreferredLanguage
                        );

                    const subjectMatch =
                        isRelevantDatabaseCourse(
                            course.title,
                            course.description,
                            course.category,
                            course.channelName,
                            query
                        );

                    return (
                        languageMatch &&
                        subjectMatch
                    );
                }
            );


        /* =================================================
           15. SORT FINAL RESULTS
        ================================================= */

        finalRelevantCourses.sort(
            (a, b) =>
                (
                    b.recommendationScore ??
                    0
                ) -
                (
                    a.recommendationScore ??
                    0
                )
        );


        console.log(
            "Final courses:",
            finalRelevantCourses.length
        );


        console.log(
            "Final videos:",
            finalRelevantCourses.filter(
                (course) =>
                    course.courseType ===
                    "VIDEO"
            ).length
        );


        console.log(
            "Final playlists:",
            finalRelevantCourses.filter(
                (course) =>
                    course.courseType ===
                    "PLAYLIST"
            ).length
        );


        /* =================================================
           16. RETURN
        ================================================= */

        return NextResponse.json({

            source:
                "youtube",

            courses:
                finalRelevantCourses.slice(
                    0,
                    10
                ),
        });


    } catch (
        error
    ) {

        console.error(
            "Course search error:",
            error
        );


        return NextResponse.json(
            {
                error:
                    "Failed to search courses",
            },
            {
                status: 500,
            }
        );
    }
}