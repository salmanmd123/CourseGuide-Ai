import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";

import { db } from "@/db";
import { aiNotes, courses, lessons } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";

const NVIDIA_API_URL =
    "https://integrate.api.nvidia.com/v1/chat/completions";

const DEFAULT_MODEL =
    "nvidia/nemotron-3.5-lightning-30b-a3b";

function cleanGeneratedNotes(
    content: string
): string {
    let cleaned =
        content.trim();

    /*
     * Remove common reasoning/thinking
     * sections if the model accidentally
     * exposes them.
     */

    const lessonSummaryIndex =
        cleaned.indexOf(
            "## Lesson Summary"
        );

    if (
        lessonSummaryIndex > 0
    ) {
        cleaned =
            cleaned.slice(
                lessonSummaryIndex
            );
    }

    /*
     * Remove accidental final
     * meta commentary.
     */

    const unwantedSections = [
        "## Check against constraints",
        "## Constraint Check",
        "## Analysis",
        "## Thinking Process",
        "## Reasoning",
    ];

    for (const section of unwantedSections) {
        const index =
            cleaned.indexOf(
                section
            );

        if (index >= 0) {
            cleaned =
                cleaned.slice(
                    0,
                    index
                ).trim();
        }
    }

    return cleaned.trim();
}

/* =========================================================
   NVIDIA ERROR MESSAGE
========================================================= */

function getErrorMessage(data: unknown): string {
    if (
        typeof data === "object" &&
        data !== null &&
        "error" in data
    ) {
        const error = (
            data as {
                error?: unknown;
            }
        ).error;

        if (
            typeof error === "object" &&
            error !== null &&
            "message" in error
        ) {
            const message = (
                error as {
                    message?: unknown;
                }
            ).message;

            if (typeof message === "string") {
                return message;
            }
        }

        if (typeof error === "string") {
            return error;
        }
    }

    return "NVIDIA AI request failed";
}

/* =========================================================
   GET AI NOTES
   IMPORTANT:
   Notes are shared between ALL users.
========================================================= */

export async function GET(
    request: Request
) {
    try {
        const user =
            await getCurrentUser();

        if (!user) {
            return NextResponse.json(
                {
                    error:
                        "Authentication required",
                },
                {
                    status: 401,
                }
            );
        }

        const {
            searchParams,
        } = new URL(request.url);

        const lessonId =
            Number.parseInt(
                searchParams.get(
                    "lessonId"
                ) || "",
                10
            );

        if (
            !Number.isInteger(
                lessonId
            )
        ) {
            return NextResponse.json(
                {
                    error:
                        "Invalid lessonId",
                },
                {
                    status: 400,
                }
            );
        }

        /*
          IMPORTANT:
          Do NOT filter by userId.
    
          The same AI note is shared by
          every learner for this lesson.
        */

        const [note] =
            await db
                .select()
                .from(aiNotes)
                .where(
                    eq(
                        aiNotes.lessonId,
                        lessonId
                    )
                )
                .limit(1);

        return NextResponse.json({
            note:
                note ?? null,
        });
    } catch (error) {
        console.error(
            "AI Notes GET error:",
            error
        );

        return NextResponse.json(
            {
                error:
                    "Failed to load AI notes",
            },
            {
                status: 500,
            }
        );
    }
}

/* =========================================================
   GENERATE AI NOTES
========================================================= */

export async function POST(
    request: Request
) {
    try {
        /* =======================================================
           AUTHENTICATION
        ======================================================= */

        const user =
            await getCurrentUser();

        if (!user) {
            return NextResponse.json(
                {
                    error:
                        "Authentication required",
                },
                {
                    status: 401,
                }
            );
        }

        /* =======================================================
           REQUEST BODY
        ======================================================= */

        const body =
            await request.json();

        const lessonId =
            Number(
                body?.lessonId
            );

        if (
            !Number.isInteger(
                lessonId
            )
        ) {
            return NextResponse.json(
                {
                    error:
                        "Invalid lessonId",
                },
                {
                    status: 400,
                }
            );
        }

        /* =======================================================
           CHECK WHETHER NOTES ALREADY EXIST
           
           This is VERY IMPORTANT.
    
           If notes already exist:
           - Do NOT call NVIDIA
           - Do NOT regenerate
           - Do NOT update
           - Return the existing notes
        ======================================================= */

        const [
            existingNote,
        ] = await db
            .select()
            .from(aiNotes)
            .where(
                eq(
                    aiNotes.lessonId,
                    lessonId
                )
            )
            .limit(1);

        if (existingNote) {
            return NextResponse.json({
                note:
                    existingNote,
                alreadyExists:
                    true,
            });
        }

        /* =======================================================
           GET LESSON
        ======================================================= */

        const [lesson] =
            await db
                .select()
                .from(lessons)
                .where(
                    eq(
                        lessons.id,
                        lessonId
                    )
                )
                .limit(1);

        if (!lesson) {
            return NextResponse.json(
                {
                    error:
                        "Lesson not found",
                },
                {
                    status: 404,
                }
            );
        }

        /* =======================================================
           GET COURSE
        ======================================================= */

        const [course] =
            await db
                .select({
                    id: courses.id,
                    title: courses.title,
                })
                .from(courses)
                .where(
                    eq(
                        courses.id,
                        lesson.courseId
                    )
                )
                .limit(1);

        if (!course) {
            return NextResponse.json(
                {
                    error:
                        "Course not found",
                },
                {
                    status: 404,
                }
            );
        }

        /* =======================================================
           NVIDIA API KEY
        ======================================================= */

        const apiKey =
            process.env
                .NVIDIA_API_KEY;

        if (!apiKey) {
            return NextResponse.json(
                {
                    error:
                        "NVIDIA_API_KEY is not configured. Add it to .env.local.",
                },
                {
                    status: 500,
                }
            );
        }

        /* =======================================================
           MODEL
        ======================================================= */

        const model =
            process.env
                .NVIDIA_NIM_MODEL ||
            DEFAULT_MODEL;

        /* =======================================================
           LESSON INFORMATION
        ======================================================= */

        const description =
            lesson.description?.trim() ||
            "No lesson description was provided.";

        const duration =
            lesson.duration ||
            "Not specified";

        /* =======================================================
           AI PROMPT
        ======================================================= */

        const prompt = `
You are CourseGuide AI.

Create high-quality study notes for a
college student.

COURSE:
${course.title}

LESSON:
${lesson.title}

DURATION:
${duration}

LESSON DESCRIPTION:
${description}

IMPORTANT:

The actual YouTube transcript has not yet
been provided.

Use ONLY the information provided above.

Do not invent technical facts.

Do not claim that you watched the video.

Do not claim that you listened to the video.

Do not claim that you read a transcript.

Do not create information that is not
supported by the lesson information.

OUTPUT RULE:

Your response must contain ONLY the final
study notes.

NEVER output:

- your reasoning
- your thinking process
- analysis of the user input
- analysis of the instructions
- constraint checking
- planning
- self-criticism
- explanations about how you generated
  the answer
- statements such as "Here's a thinking
  process"
- statements such as "Let's analyze"
- statements such as "Check against
  constraints"

Start your response DIRECTLY with:

## Lesson Summary

Use exactly these sections:

## Lesson Summary

Write a concise explanation of what this
lesson covers.

## Key Concepts

- List the important concepts supported
  by the lesson information.
- Give a simple explanation for each.

## Important Points

- Give useful revision points.
- Keep them concise.
- Do not add unsupported facts.

## Example

Provide an example only if it can be
reasonably derived from the provided
information.

If there is not enough information,
write exactly:

No example was provided in the lesson information.

## Quick Revision

- Give short points useful for revision.
- Keep them simple.
- Make them suitable for a college student.

STYLE:

- Simple English.
- Student-friendly.
- Clear.
- Concise.
- No unnecessary introduction.
- No repetition.
- No reasoning.
- No meta commentary.
- Only final notes.
`;

        /* =======================================================
           CALL NVIDIA NIM
        ======================================================= */

        const nvidiaResponse =
            await fetch(
                NVIDIA_API_URL,
                {
                    method: "POST",

                    headers: {
                        "Content-Type":
                            "application/json",

                        Authorization:
                            `Bearer ${apiKey}`,
                    },

                    body: JSON.stringify({
                        model,

                        messages: [
                            {
                                role: "system",
                                content:
                                    "You are CourseGuide AI, an accurate and student-friendly educational notes assistant.",
                            },

                            {
                                role: "user",
                                content:
                                    prompt,
                            },
                        ],

                        temperature: 0.2,

                        top_p: 0.7,

                        max_tokens: 1600,

                        stream: false,
                    }),
                }
            );

        const responseData =
            await nvidiaResponse.json();

        /* =======================================================
           NVIDIA ERROR
        ======================================================= */

        if (
            !nvidiaResponse.ok
        ) {
            console.error(
                "NVIDIA API error:",
                responseData
            );

            return NextResponse.json(
                {
                    error:
                        getErrorMessage(
                            responseData
                        ),
                },
                {
                    status: 502,
                }
            );
        }

        /* =======================================================
           EXTRACT AI CONTENT
        ======================================================= */

        const content =
            responseData
                ?.choices?.[0]
                ?.message?.content;

        if (
            typeof content !==
            "string" ||
            !content.trim()
        ) {
            console.error(
                "Unexpected NVIDIA response:",
                responseData
            );

            return NextResponse.json(
                {
                    error:
                        "NVIDIA AI returned empty notes",
                },
                {
                    status: 502,
                }
            );
        }

        const noteContent =
            cleanGeneratedNotes(
                content
            );

        /* =======================================================
           SAVE SHARED NOTE
           
           userId = user who originally
           generated the note.
    
           lessonId = the lesson this note
           belongs to.
    
           The note is retrieved by lessonId,
           so ALL users see the same content.
        ======================================================= */

        const [
            createdNote,
        ] = await db
            .insert(aiNotes)
            .values({
                userId:
                    user.id,

                lessonId,

                content:
                    noteContent,
            })
            .returning();

        return NextResponse.json({
            note:
                createdNote,
            alreadyExists:
                false,
        });
    } catch (error) {
        console.error(
            "AI Notes POST error:",
            error
        );

        return NextResponse.json(
            {
                error:
                    "Failed to generate AI notes",
            },
            {
                status: 500,
            }
        );
    }
}